# NitroGen
Discord bot to generate nitro gift codes

# Hosting on Heroku

Host on heroku and just add TOKEN in env variables on heroku dashboard
